
# Verification Scripting Toolkit (Python)

This repository is a **starter template** for digital design verification scripting.  
It bundles reusable Python utilities for:

* Running parallel regression suites
* Parsing simulator logs (VCS, Questa, Xcelium)
* Merging coverage summaries
* Generating HTML/CSV reports

## Folder Structure
```
verification_scripts_template/
├── scripts/        # Ready‑to‑use command‑line tools
├── configs/        # YAML/JSON examples
├── tests/          # Unit tests
├── docs/           # Additional docs / examples
├── requirements.txt
├── LICENSE
└── README.md
```

## Quick Start
```bash
python -m venv venv
source venv/bin/activate   # .\venv\Scripts\activate on Windows
pip install -r requirements.txt

# Run a sample regression
python scripts/run_regression.py --testlist configs/example_testlist.yaml
```

## Scripts
| Script | What it does |
|--------|--------------|
| `run_regression.py` | Spawns multiple simulations in parallel & aggregates pass/fail |
| `parse_logs.py` | Extracts errors/warnings from simulator output |
| `merge_coverage.py` | Combines coverage DBs or JSON summaries |

## Contributing
1. Fork the repo
2. Create a feature branch
3. Submit a PR

MIT Licensed. Enjoy!
