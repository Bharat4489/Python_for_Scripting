
#!/usr/bin/env python3
"""Parse simulator logs and extract errors/warnings."""
import argparse, re, sys, pathlib

ERROR_PAT = re.compile(r'^(?=.*(ERROR|FATAL))', re.IGNORECASE)
WARN_PAT = re.compile(r'^(?=.*(WARNING))', re.IGNORECASE)

def main():
    parser = argparse.ArgumentParser(description='Log parser')
    parser.add_argument('logfile', help='Simulator log file')
    args = parser.parse_args()

    errors, warnings = [], []
    with open(args.logfile, errors='ignore') as f:
        for line in f:
            if ERROR_PAT.search(line):
                errors.append(line.strip())
            elif WARN_PAT.search(line):
                warnings.append(line.strip())
    print(f"Errors: {len(errors)}, Warnings: {len(warnings)}")
    if errors:
        print("--- Errors ---")
        print("\n".join(errors[:20]))
    if warnings:
        print("--- Warnings ---")
        print("\n".join(warnings[:20]))

if __name__ == '__main__':
    main()
