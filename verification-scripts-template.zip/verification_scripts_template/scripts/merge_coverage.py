
#!/usr/bin/env python3
"""Merge JSON coverage summaries into one report."""
import argparse, json, pathlib
from collections import defaultdict

def main():
    parser = argparse.ArgumentParser(description='Merge coverage JSON files')
    parser.add_argument('files', nargs='+', help='Coverage JSON files')
    parser.add_argument('-o', '--out', default='merged_coverage.json',
                        help='Output JSON')
    args = parser.parse_args()

    merged = defaultdict(int)
    for fp in args.files:
        with open(fp) as f:
            data = json.load(f)
            for k, v in data.items():
                merged[k] += v
    with open(args.out, 'w') as f:
        json.dump(merged, f, indent=2)
    print(f"Merged coverage written to {args.out}")

if __name__ == '__main__':
    main()
